法律人的 Vibe Coding｜本機 Python 練習包
作者：錢世傑｜2026-10-23｜CC BY-NC 4.0

先看完整講義：
https://mjib007.github.io/criminal-law-interpretation/lectures/vibe-coding-python.html

1. 依講義安裝環境，用 Anaconda Prompt 啟動 Jupyter。
2. 將本練習包解壓縮，把 notebook-to-python.ipynb 與 worklog.py 放進 law_vibe 工作資料夾。
3. 在 Jupyter 開啟 notebook-to-python.ipynb，由上往下執行。
4. 第 04 步會重新寫入同資料夾的 worklog.py；修改前可先備份舊版。
5. 另開 Anaconda Prompt，用 python worklog.py 獨立執行。

原版總計：75 分鐘（1 小時 15 分鐘）。加入準備簡報 20 分鐘後：95 分鐘（1 小時 35 分鐘）。
範例使用虛構活動，只做分鐘加總；不需要 API 金鑰或外部業務套件。
.ipynb 是工作筆記，.py 是純 Python 程式；.py 執行仍需要 Python。
授權條款：https://github.com/mjib007/criminal-law-interpretation/blob/main/LICENSE.md
